//C program to sort by selection sort in descending order
#include <stdio.h>
int num;
//function to swap the position of two element
void swap(int t[], int i, int j)
{
    int x;
    x=t[i];
    t[i]=t[j];
    t[j]=x;
}

void sort(int a[])
{
    int i,j;
    for(i=0;i<num;i++)
    {
        for(j=(i+1);j<num;j++)
        {
            if(a[i]<a[j])
                swap(a,i,j);
        }
    }
    for(i=0;i<num;i++)
    {
        printf("%d\t", a[i]);
    }
}
int main()
{
    printf("Enter the size of the list(array) \t");
    scanf("%d",&num);
    int m[num],i;
     printf("Enter the elements \n");
     for(i=0;i<num;i++)
    {
        scanf("%d",&m[i]);
    }
     printf("The original list is: \n");
     for(i=0;i<num;i++)
    {
       printf("%d\t",m[i]);
    }
    printf("\n\n");
    printf("The sorted array is: \n");
    sort(m);
    return 0;
}

